import { expect } from "@playwright/test"

export class ProductsPage {
    constructor(page) {
        this.page = page

        this.addButtons = page.locator('[data-qa="product-button"]')
        this.basketCounter = page.locator('[data-qa="header-basket-count"]')
    }

    visit = async() => {
        await this.page.goto("/")
    }

    getbasketCount = async () => {
        await this.basketCounter.waitFor()
        //return
        const text = await this.basketCounter.innerText()
        // "0" -> 0
        return parseInt(text, 10)
    }

    addProductToBasket = async (index) => {
        const specificxAddButton = this.addButtons.nth(index)
        await specificxAddButton.waitFor()
        await expect(specificxAddButton).toHaveText("Add to Basket")
        const basketCountBeforeAdding = await this.getbasketCount()
        await specificxAddButton.click()
        await expect(specificxAddButton).toHaveText("Remove from Basket")
        const basketCountAfterAdding = await this.getbasketCount()
        expect(basketCountAfterAdding).toBeGreaterThan(basketCountBeforeAdding)
        
    }
}