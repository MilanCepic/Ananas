import { test, expect } from "@playwright/test";

test("Ananas Page - Product Verification with Banner Check", async ({ page }) => {
    await page.goto("https://ananas.rs/");

   
    // Klik na dugme "Slažem se"
    const slazemSeButton = page.locator('[class="sc-1rhklln-0 gIUtAK"]');
    await slazemSeButton.click();

    // Funkcija koja proverava i zatvara baner
    const closeBannerIfExists = async () => {
        const closeButton = page.locator('svg.close-button');
        const closeButtonCount = await closeButton.count();
        if (closeButtonCount > 0) {
           await closeButton.click(); 
        }
    };

     // Provera baner na svakih 2 sekunde
     const bannerCheckInterval = setInterval(async () => {
    await closeBannerIfExists();
    }, 2000);

    // Pretraga proizvoda
    const searchBar = page.locator('[class="aa-Input"]');
    await searchBar.click();
    await searchBar.fill("patike");

    const searchButton = page.locator('[aria-label="Search"]');
    await searchButton.click();

    // Lokator za sve proizvode na stranici
    const allProductsParent = page.locator('[class="ais-Hits"]'); // Parent element za proizvode
    const products = allProductsParent.locator('[class="ais-Hits-item"]'); // Child lokator za svaki proizvod
    const productCount = await products.count();

    // Provera proizvoda na stranici
    for (let i = 0; i < productCount; i++) {
        const product = products.nth(i);

        // Provera da li proizvod ima sliku
        const image = product.locator('img[alt]:not([aria-hidden="true"])').first();
        await expect(image).toHaveAttribute("alt", /.+/);

        // Provera da li proizvod ima cenu sa oznakom RSD
        const price = product.locator('[class="sc-1arj7wv-3 hasJsD"]');
        await expect(price).toContainText("RSD");

        // Provera da li proizvod ima naslov i opis
        const titleAndDescription = product.locator('[class="sc-14no49n-0 sc-492kdg-1 eZmkQR bmZJba"]');
        await expect(titleAndDescription).toHaveText(/.+/);
    }
    //await page.pause();
    // Klik na paginaciju '2'
    const paginationButton2 = page.locator('[class="sc-hj4qyi-0 czzIrF"]').filter({ hasText: "2" });
    await paginationButton2.click();

    // Proveravamo proizvode na drugoj stranici
    const secondPageProducts = allProductsParent.locator('[class="ais-Hits-item"]');
    const secondPageProductCount = await secondPageProducts.count();

    for (let i = 0; i < secondPageProductCount; i++) {
        const product = secondPageProducts.nth(i);

        // Provera da li proizvod ima sliku
        const image = product.locator('img[alt]:not([aria-hidden="true"])').first();
        await expect(image).toHaveAttribute("alt", /.+/);

        // Provera da li proizvod ima cenu sa oznakom RSD
        const price = product.locator('[class="sc-1arj7wv-3 hasJsD"]');
        await expect(price).toContainText("RSD");

        // Provera da li proizvod ima naslov i opis
        const titleAndDescription = product.locator('[class="sc-14no49n-0 sc-492kdg-1 eZmkQR bmZJba"]');
        await expect(titleAndDescription).toHaveText(/.+/);
    }
    //await page.pause();

    // Klik na paginaciju 'Next'
    const nextPaginationButton = page.locator('[class="ais-Pagination-item ais-Pagination-item--nextPage"]');
    await nextPaginationButton.click();

    // Proveravamo proizvode na trecoj stranici
    const thirdPageProducts = allProductsParent.locator('[class="ais-Hits-item"]');
    const thirdPageProductCount = await thirdPageProducts.count();

    for (let i = 0; i < thirdPageProductCount; i++) {
        const product = thirdPageProducts.nth(i);

        // Provera da li proizvod ima sliku
        const image = product.locator('img[alt]:not([aria-hidden="true"])').first();
        await expect(image).toHaveAttribute("alt", /.+/);

        // Provera da li proizvod ima cenu sa oznakom RSD
        const price = product.locator('[class="sc-1arj7wv-3 hasJsD"]');
        await expect(price).toContainText("RSD");

        // Provera da li proizvod ima naslov i opis
        const titleAndDescription = product.locator('[class="sc-14no49n-0 sc-492kdg-1 eZmkQR bmZJba"]');
        await expect(titleAndDescription).toHaveText(/.+/);
    }

    // Stop baner interval
    clearInterval(bannerCheckInterval);

    //await page.pause();
});